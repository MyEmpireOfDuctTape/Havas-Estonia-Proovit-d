<?php
/*
Plugin Name: My options page.
Description: Plugin that adds an options page which contains a grid of links to all the posts.
Version: 1.0
Author: Anton Kuksov
*/

/*  Copyright 2019  Anton_Kuksov  (email: antkuk123@gmail.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


add_action('admin_menu', 'my_plugin_menu');
function my_plugin_menu()
{
    add_options_page('My Option', 'My option', 'manage_options', 'my-plugin', 'my_plugin_page');
}


function the_excerpt_max_charlength($charlength, $excerpt)
{
    $charlength++;
    if (mb_strlen($excerpt) > $charlength) {
        $subex = mb_substr($excerpt, 0, $charlength - 5);
        $exwords = explode(' ', $subex);
        $excut = -(mb_strlen($exwords[count($exwords) - 1]));
        if ($excut < 0) {
            echo mb_substr($subex, 0, $excut);
        } else {
            echo $subex;
        }
        echo '[...]';
    } else {
        echo $excerpt;
    }
}


function my_plugin_page()
{
    ?>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

    <div class="container pt-5">

        <?php
        $counter = 1;
        $grids = 2;
        global $query_string;
        query_posts($query_string . '&caller_get_posts=1&posts_per_page=-1');

        if (have_posts()) :  while (have_posts()) :  the_post();
                ?>
                <?php
                //Show the left hand side column
                if ($counter == 1) :
                    ?>

                    <div class="row bg-light">
                        <div class="col border">
                            <a href=" <?php echo get_edit_post_link(); ?> " title="<?php the_title_attribute(); ?>">
                                <?php
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('plugin-thumb');
                                } else {
                                    echo '<img src="' . plugins_url('grid-of-links/greysquare.png') . '" width="100px" />';
                                }
                                ?>
                            </a>
                            <h2><a href="<?php echo get_edit_post_link(); ?>" title="<?php the_title_attribute(); ?>">
                                    <?php the_title(); ?></a></h2>
                            <?php the_excerpt_max_charlength(130, get_the_excerpt()); ?>
                            <a href="<?php the_permalink(); ?>">Link</a>
                        </div>
                    <?php
                    //Show the right hand side column
                    elseif ($counter == $grids) :
                        ?>

                        <div class="col border">
                            <a href=" <?php echo get_edit_post_link(); ?> " title="<?php the_title_attribute(); ?>">
                                <?php
                                if (has_post_thumbnail()) {
                                    the_post_thumbnail('plugin-thumb');
                                } else {
                                    echo '<img src="' . plugins_url('grid-of-links/greysquare.png') . '" width="100px" />';
                                }
                                ?>
                            </a>
                            <h2><a href="<?php echo get_edit_post_link(); ?>" title="<?php the_title_attribute(); ?>">
                                    <?php the_title(); ?></a></h2>
                            <?php the_excerpt_max_charlength(130, get_the_excerpt()); ?>
                            <a href="<?php the_permalink(); ?>">Link</a>

                        </div>
                        <div class="clear"></div>
                    </div>
                    <?php
                    $counter = 0;
                endif;
                ?>
                <?php
                $counter++;
            endwhile;
        //Pagination can go here if you want it.
        endif;
        ?>


    </div>


<?php
}
